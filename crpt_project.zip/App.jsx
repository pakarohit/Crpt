
import React, { useState } from "react";

const tokens = ["ETH", "USDT", "BTC", "MATIC"];

function TokenSelector({ selected, onSelect }) {
  return (
    <select
      value={selected}
      onChange={(e) => onSelect(e.target.value)}
      className="w-full px-3 py-2 rounded-lg bg-gray-700 focus:outline-none"
    >
      {tokens.map((token) => (
        <option key={token} value={token}>
          {token}
        </option>
      ))}
    </select>
  );
}

function WalletConnect() {
  const [connected, setConnected] = useState(false);
  return (
    <button
      onClick={() => setConnected(!connected)}
      className="w-full mb-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg"
    >
      {connected ? "Wallet Connected" : "Connect Wallet"}
    </button>
  );
}

function SwapButton({ from, to, amount }) {
  const handleSwap = () => {
    if (!amount || Number(amount) <= 0) return alert("Enter a valid amount");
    alert(`Swapping ${amount} ${from} to ${to}`);
  };

  return (
    <button
      onClick={handleSwap}
      className="w-full mt-4 py-2 bg-green-500 hover:bg-green-600 rounded-lg"
    >
      Swap
    </button>
  );
}

export default function App() {
  const [fromToken, setFromToken] = useState("ETH");
  const [toToken, setToToken] = useState("USDT");
  const [amount, setAmount] = useState("");

  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-4">
      <div className="bg-gray-800 p-6 rounded-2xl shadow-2xl w-full max-w-md">
        <h1 className="text-2xl font-bold mb-4 text-center">crpt - Token Swap</h1>

        <WalletConnect />

        <div className="my-4">
          <label className="block text-sm mb-1">From Token</label>
          <TokenSelector selected={fromToken} onSelect={setFromToken} />
        </div>

        <div className="my-4">
          <label className="block text-sm mb-1">To Token</label>
          <TokenSelector selected={toToken} onSelect={setToToken} />
        </div>

        <div className="my-4">
          <label className="block text-sm mb-1">Amount</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full px-3 py-2 rounded-lg bg-gray-700 focus:outline-none"
          />
        </div>

        <SwapButton from={fromToken} to={toToken} amount={amount} />
      </div>
    </div>
  );
}
